public class Project3 {
//1 Создайте строковую переменную, положите в неё "I study Basic Java!" или любое другое предложение
//2 Распечатайте первый символ строки. Используем метод String.charAt().
//3 Распечатайте последний символ строки.
//4 Проверить, содержит ли Ваша строка подстроку “Java”. Используем метод String.contains(). Вывести в консоль результат проверки
//5 Заменить все символы "а" на "о". Вывести в консоль результат
//6 Преобразуйте строку к верхнему регистру. Выведите в консоль
//7 Преобразуйте строку к нижнему регистру. Выведите в консоль
//8 Вырезать подстроку "Java" c помощью метода String.substring().

    public static void main(String[] args) {
        String str = "I study Basic Java!";

        System.out.println(str.charAt(0));
        System.out.println(str.charAt(str.length() - 1));
        if (str.contains("Java")) {
            System.out.println("Stroka sodergit podstroku 'Java'");
        } else {
            System.out.println("Stroka ne sodergit 'Java'");
        }
        String value = "I study Basic Java!".replace("a","o");
        System.out.println(value);
        String Upper = str.toUpperCase();
        System.out.println(Upper);
        String Lower = str.toLowerCase();
        System.out.println(Lower);
        System.out.println(str.length());
        System.out.println(str.substring(str.length() -5, str.length() - 1));
        System.out.println(str.substring(14,18));

    }
}