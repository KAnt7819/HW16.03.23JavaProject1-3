public class Project1 {

    // 1 уровень сложности: Проект 1
//1 Создайте переменную byte b = 1;
//2 Присвойте её значение новым переменным типов short, int, long, double.
//3 Выведите значение новых переменных в консоль.
    public static void main(String[] args) {

        byte b = 1;
        short s = b;
        System.out.println(s);
        int i = b;
        System.out.println(i);
        long l = b;
        System.out.println(l);
        double d = b;
        System.out.println(d);
    }
}